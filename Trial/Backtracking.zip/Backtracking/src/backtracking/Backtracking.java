/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backtracking;

import java.util.Stack;

/**
 *
 * @author sofyan
 */
public class Backtracking {

    /**
     * @param args the command line arguments
     */
    static int count = 0;
    static Stack stack = new Stack();

    public static void proses_rekursif(int[][] matriks, int i, int j) {
        int[][] tempMatriks = new int[3][3];
        int xx, yy;
        if (true) {
            if (i < 3 && j < 3 && i > -1 && j > -1) {
                for (int y = 0; y < 3; y++) {
                    for (int x = 0; x < 3; x++) {
                        tempMatriks[x][y] = matriks[x][y];
                        System.out.print(matriks[x][y] + " ");
                    }
                    System.out.println("");
                }
                stack.push(tempMatriks);
                System.out.println("masuk ke : " + count++);
                System.out.println("---------------");

                if (cekSolusi(matriks, i, j) && matriks[i][j] != 0) {
                    //matriks[i][j] = 1;
                    buatNol(matriks, i, j);
                } else {
                    matriks[i][j] = 0;
                    //proses_rekursif(matriks, i + 1, j);

                    proses_rekursif(matriks, i + 1, j);
                }
                
                proses_rekursif(matriks, 0, j + 1);

                //jalan(tempMatriks, 0, j);
            /*if (true){
                 matriks[i][j-1]=0;
                 proses_rekursif(matriks, i+1, j - 1);
                
                 } */
            }
        }


        /*if (j == 2 || !cekFinal()) {
         proses_rekursif(matriks, i, j - 1);
         } */
    }

    public static int[][] proses(int[][] matriks, int i, int j) {

        if (cekSolusi(matriks, i, j) && matriks[i][j] != 0) {
            //matriks[i][j] = 1;
            System.out.println("masuk1");
            buatNol(matriks, i, j);
        } else {
            System.out.println("masuk2");
            matriks[i][j] = 0;
        }
        return matriks;
    }

    public static void jalan(int[][] matriks, int i, int j) {
        proses_rekursif(matriks, i, j);
    }

    //cek keberadaan "1" di satu kolom yang sama
    public static boolean cekSolusi(int[][] matriks, int kolom, int baris) {
        boolean status = true;
        int x = baris - 1;
        while (status && x >= 0) {
            if (matriks[kolom][x] == 1) {
                status = false;
            }
            x--;
        }
        x = baris + 1;
        /*while (status && x < 3) {
         if (matriks[kolom][x] == 1) {
         status = false;
         }
         x++;
         } */
        return status;
    }

    //prosedur set nol semua yang sebelah kanan
    public static void buatNol(int[][] matriks, int kolom, int baris) {
        for (int x = kolom + 1; x < 3; x++) {
            matriks[x][baris] = 0;
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        int i = 0, j = 0;
        //int[][] matriks = {{1, 1, 1}, {1, 1, 0}, {0, 1, 1}};
        //int[][] matriks = {{1, 1, 0}, {1, 1, 1}, {1, 0, 1}};
        //int[][] matriks = {{1, 0, 1}, {0, 0, 0}, {0, 0, 1}};
        //int[][] matriks2 = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
        int[][] matriks = {{0, 1, 1}, {1, 0, 1}, {0, 1, 1}};
        int[][] c;
        //matriks[2][0] = 1;
        jalan(matriks, i, j);
        //proses(matriks,i,j);
        System.out.println("kapasitas stack : " + stack.capacity());
        while (!stack.empty()) {
            c = (int[][]) stack.pop();
            for (int y = 0; y < 3; y++) {
                for (int x = 0; x < 3; x++) {
                    c[x][y] = matriks[x][y];
                    System.out.print(matriks[x][y] + " ");
                }
                System.out.println("");
            }
            System.out.println("-------------------------------------------------");
        }
    }

}
